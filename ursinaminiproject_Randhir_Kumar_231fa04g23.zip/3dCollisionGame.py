from ursina import *
import random

app = Ursina()

# Window setup
window.title = 'Classic Pong with Timer and Winner Announcement'
window.borderless = False
window.fps_counter.enabled = True
camera.orthographic = True
camera.fov = 20

# Game variables
paddle_speed = 10
ball_speed = Vec2(10, 10)
score_left = 0
score_right = 0
game_duration = 60  # Total game time in seconds
time_remaining = game_duration
game_over = False

# Paddle setup
paddle_left = Entity(model='quad', color=color.azure, scale=(0.5, 3), position=(-7, 0), collider='box')
paddle_right = Entity(model='quad', color=color.orange, scale=(0.5, 3), position=(7, 0), collider='box')

# Ball setup
ball = Entity(model='circle', color=color.white, scale=0.5, position=(0, 0), collider='box')

# Wall setup
top_wall = Entity(model='quad', color=color.gray, scale=(16, 0.5), position=(0, 5), collider='box')
bottom_wall = Entity(model='quad', color=color.gray, scale=(16, 0.5), position=(0, -5), collider='box')

# Score and timer display
score_text = Text(text=f'{score_left}    {score_right}', position=(-0.1, 0.45), scale=2, background=True)
timer_text = Text(text=f'Time: {int(time_remaining)}', position=(0.35, 0.45), scale=2, background=True)

# Winner announcement
winner_text = Text(text='', position=(0, 0), origin=(0, 0), scale=3, background=True)
winner_text.visible = False

def reset_ball():
    ball.position = (0, 0)
    ball_speed.x *= random.choice([-1, 1])
    ball_speed.y *= random.choice([-1, 1])

def update():
    global score_left, score_right, time_remaining, game_over

    if not game_over:
        # Update timer
        time_remaining -= time.dt
        if time_remaining > 0:
            timer_text.text = f'Time: {int(time_remaining)}'
        else:
            timer_text.text = 'Time: 0'
            game_over = True
            ball.visible = False
            paddle_left.visible = False
            paddle_right.visible = False
            # Determine winner
            if score_left > score_right:
                winner_text.text = 'Player 1 Wins!'
            elif score_right > score_left:
                winner_text.text = 'Player 2 Wins!'
            else:
                winner_text.text = "It's a Tie!"
            winner_text.visible = True
            return

        # Paddle movement
        if held_keys['w'] and paddle_left.y < 4:
            paddle_left.y += paddle_speed * time.dt
        if held_keys['s'] and paddle_left.y > -4:
            paddle_left.y -= paddle_speed * time.dt
        if held_keys['up arrow'] and paddle_right.y < 4:
            paddle_right.y += paddle_speed * time.dt
        if held_keys['down arrow'] and paddle_right.y > -4:
            paddle_right.y -= paddle_speed * time.dt

        # Ball movement
        ball.x += ball_speed.x * time.dt
        ball.y += ball_speed.y * time.dt

        # Ball collision with top wall
        if ball.intersects(top_wall).hit:
            ball_speed.y *= -1
            top_wall.color = color.red
            invoke(setattr, top_wall, 'color', color.gray, delay=0.1)

        # Ball collision with bottom wall
        if ball.intersects(bottom_wall).hit:
            ball_speed.y *= -1
            bottom_wall.color = color.red
            invoke(setattr, bottom_wall, 'color', color.gray, delay=0.1)

        # Ball collision with paddles
        if ball.intersects(paddle_left).hit or ball.intersects(paddle_right).hit:
            ball_speed.x *= -1

        # Ball out of bounds
        if ball.x < -8:
            score_right += 1
            score_text.text = f'{score_left}    {score_right}'
            reset_ball()
        if ball.x > 8:
            score_left += 1
            score_text.text = f'{score_left}    {score_right}'
            reset_ball()

reset_ball()
app.run()
